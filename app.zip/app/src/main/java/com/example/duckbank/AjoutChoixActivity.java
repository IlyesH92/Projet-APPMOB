package com.example.duckbank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.duckbank.R.layout.activity_ajoutchoix;

public class AjoutChoixActivity extends AppCompatActivity {

    private Button btnChoixGain;
    private Button btnChoixDepense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_ajoutchoix);

        btnChoixGain = (Button) findViewById(R.id.btnChoixGain);
        btnChoixDepense = (Button) findViewById(R.id.btnChoixDepense);

        btnChoixGain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gameActivity = new Intent(AjoutChoixActivity.this, AjoutGainActivity.class);
                startActivity(gameActivity);
            }
        });

        btnChoixDepense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gameActivity = new Intent(AjoutChoixActivity.this, AjoutDepenseActivity.class);
                startActivity(gameActivity);
            }
        });
    }
}