package com.example.duckbank;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AjoutDepenseActivity extends AppCompatActivity {

    Spinner sp;
    Button btnDepenser;
    Button btnRetour;
    EditText zoneInputDepense;
    String[]tab = new String[]{"restaurant","voiture","divertissement","shopping"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajoutdepense);

        //initialisation variable

        sp = (Spinner) findViewById(R.id.spAjoutDepense);
        btnDepenser = (Button) findViewById(R.id.btnAjoutDepense);
        btnRetour = (Button) findViewById(R.id.btnRetourAjoutDepense);
        zoneInputDepense = (EditText) findViewById(R.id.zoneTexteAjoutDepense);

        //bouton depenser intouchable

        btnDepenser.setEnabled(false);

        //remplissage de la liste

        ArrayAdapter<String> da = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,tab);
        sp.setAdapter(da);

        //Action sur la zone de nombre

        zoneInputDepense.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                int val = Integer.parseInt(s.toString());
                btnDepenser.setEnabled(s.toString().length() != 0 && val > 0);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // Action sur le bouton retour

        btnRetour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gameActivity = new Intent(AjoutDepenseActivity.this, MainActivity.class);
                startActivity(gameActivity);

            }
        });

        //Action sur le bouton depenser

        btnDepenser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), zoneInputDepense.getText().toString()+"€ dépensé(s) pour " +sp.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
                Intent gameActivity = new Intent(AjoutDepenseActivity.this, MainActivity.class);
                startActivity(gameActivity);

            }
        });


    }

}
